package main

import (
	"database/sql"
	"fmt"

	//"fmt"
	"log"
	"net/http"
	"text/template"
	"time"

	_ "github.com/go-sql-driver/mysql"
	
)

type customer struct {
	Ticket_id        int
	Name             string
	Alternate_number int
	Number           int
	Date_of_birth    string
	Gender           string
	Address          string
	Pincode          string
	Planactive       string
}
type plan struct{
	Planid int
	Planduration string
	Voicecalllimit string
	Datallimit string
	Smslimit string
	Plancost int

}
func dbConn() (db *sql.DB) {
	dbDriver := "mysql"
	dbUser := "root"
	dbPass := "root"
	dbName := "golangapp"
	db, err := sql.Open(dbDriver, dbUser+":"+dbPass+"@/"+dbName)
	if err != nil {
		panic(err.Error())
	}
	return db
}
var tmpl = template.Must(template.ParseGlob("Template/*"))

func Index(w http.ResponseWriter, r *http.Request) {

	tmpl.ExecuteTemplate(w, "Index", nil)
}
func Enterdetails(w http.ResponseWriter, r *http.Request){
	tmpl.ExecuteTemplate(w, "Enterdetails", nil)
}

func insert(w http.ResponseWriter, r *http.Request){
	db := dbConn()
	if r.Method == "POST" {
		id := r.FormValue("id")
		name:= r.FormValue("name")
		altno := r.FormValue("altno")
		number:=r.FormValue("number")
		dob := r.FormValue("dob")
		gender := r.FormValue("gender")
		Address:=r.FormValue("Address")
		Pincode:=r.FormValue("Pincode")
		Planactive:=r.FormValue("Planactive")
		insForm, err := db.Prepare("INSERT INTO Customerdetails(name,altno,number,Dob,gender,address,pincode,planactive) VALUES(?,?,?,?,?,?,?,?)")
		if err != nil {
			panic(err.Error())
		}
		a,err:=insForm.Exec(name,altno,number,dob,gender,Address,Pincode,Planactive)
		fmt.Println(a)
		if(err!=nil){
			panic(err.Error())
		}
		fmt.Println(id,name,altno,dob,gender,Address,Pincode,Planactive)

	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}
func Searchtemplate(w http.ResponseWriter, r *http.Request) {
	fmt.Println("Under search")
	tmpl.ExecuteTemplate(w, "Search", nil)
}

func Searchdetails(w http.ResponseWriter, r *http.Request) {
	fmt.Println("under search details")
	cust := customer{}
	res := []customer{}
	db := dbConn()
	if r.Method == "POST" {
		name1:= r.FormValue("name")
		altno1 := r.FormValue("altno")
		number1:=r.FormValue("number")
		Address:=r.FormValue("Address")
		Pincode:=r.FormValue("Pincode")
		seldb, err := db.Query("Select * from Customerdetails where  name=? or altno=? or number=? or address=? or pincode=? ",name1,altno1,number1,Address,Pincode) 
		if err != nil {
			panic(err.Error())
		}
		//a,err:=seldb.Exec(id,name,altno,number,dob,gender,Address,Pincode,Planactive)
		
		var id,altno,number int
		var address,dob,planactive,gender,name ,pin string
		for seldb.Next() {
			fmt.Println(pin)
			err = seldb.Scan(&id,&name,&altno,&number,&dob,&gender,&address,&pin,&planactive)
			if err != nil {

				panic(err.Error())
			}
		fmt.Println("pincode",pin)
		     cust.Ticket_id=id
			cust.Name=name
			cust.Number=number
		cust.Alternate_number=altno
			
			//cust.Pincode=pin
			//cust.Address=address
			cust.Date_of_birth=dob
			cust.Gender=gender
		//	cust.Planactive=planactive
			res = append(res, cust)
			fmt.Println("ress",res)
			
	
		}
		//fmt.Println(id,name,altno,dob,gender,Address,Pincode,Planactive)
		
	}
	tmpl.ExecuteTemplate(w, "Show", res)
	defer db.Close()

}



func Show(w http.ResponseWriter, r *http.Request) {

	db := dbConn()
	seldb, err := db.Query("SELECT * FROM Customerdetails ")
	cust := customer{}
	res := []customer{}
	if err != nil {
		panic(err.Error())
	}
	var id,altno,number int
	var address,dob,planactive,gender,name ,pincode string
	for seldb.Next() {
		
		err = seldb.Scan(&id,&name,&altno,&number,&dob,&gender,&address,&pincode,&planactive)
		if err != nil {
			panic(err.Error())
		}

	    cust.Ticket_id=id
		cust.Name=name
		cust.Alternate_number=altno
		cust.Number=number
		cust.Pincode=pincode
		cust.Address=address
		cust.Date_of_birth=dob
		cust.Gender=gender
		cust.Planactive=planactive
		res = append(res, cust)

	}
	tmpl.ExecuteTemplate(w, "Show", res)
	defer db.Close()

}
func EnterPlandetails(w http.ResponseWriter, r *http.Request){
//	fmt.Println("INside enter pla")
	tmpl.ExecuteTemplate(w, "Enterplandetails", nil)
}
func Edit(w http.ResponseWriter, r *http.Request){
	
	db := dbConn()
	nId := r.URL.Query().Get("id")
	var id,altno,number int
		var address,dob,planactive,gender,name ,pin string
	selDB, err := db.Query("SELECT * FROM Customerdetails WHERE id=?", nId)
	if err != nil {
		panic(err.Error())
	}
	cust:= customer{}
	for selDB.Next() {

		err = selDB.Scan(&id, &name, &altno, &number, &dob, &gender,&address,&pin,&planactive)
		if err != nil {
			panic(err.Error())
		}
		cust.Ticket_id=id
		cust.Alternate_number=altno
		cust.Name=name
		cust.Number=number
		cust.Date_of_birth=dob
		cust.Gender=gender
		cust.Address=address
		cust.Pincode=pin
		cust.Planactive=planactive
		
	}
	tmpl.ExecuteTemplate(w, "Edit", cust)
	defer db.Close()
	//tmpl.ExecuteTemplate(w, "Edit", nil)
}
func Update(w http.ResponseWriter, r *http.Request){
	db := dbConn()
	if r.Method == "POST" {
		name1:= r.FormValue("name")
		altno1 := r.FormValue("altno")
		number1:=r.FormValue("number")
		Address:=r.FormValue("Address")
		Pincode:=r.FormValue("Pincode")
		planactive:=r.FormValue("Planactive")
		dob:=r.FormValue("dob")
		gender:=r.FormValue("gender")
		fmt.Println(gender)
		id := r.FormValue("id")
		insForm, err := db.Prepare("UPDATE Customerdetails SET name=?, altno=?,number=?,Dob=?,gender=?,address=?,pincode=?,planactive=? WHERE id=?")
		if err != nil {
			panic(err.Error())
		}
		
		insForm.Exec(name1, altno1,number1,dob, gender,Address , Pincode, planactive,id)
		
		
	}
	defer db.Close()

	http.Redirect(w, r, "/", 301)
}
func insertplan(w http.ResponseWriter, r *http.Request){
	db := dbConn()
	if r.Method == "POST" {
	//	id := r.FormValue("id")
		duration:= r.FormValue("name")
		voicecalllimit := r.FormValue("altno")
		datalimit:=r.FormValue("number")
		smslimit := r.FormValue("dob")
		Plancost := r.FormValue("gender")
		
		insForm, err := db.Prepare("INSERT INTO Plandetails(planduration,voicecalllimit,datalimit,smslimit,plancost) VALUES(?,?,?,?,?)")
		if err != nil {
			panic(err.Error())
		}
		insForm.Exec(duration,voicecalllimit,datalimit,smslimit,Plancost)
		

		//fmt.Println(id,name,altno,dob,gender,Address,Pincode,Planactive)

	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)
}
func Showplan(w http.ResponseWriter, r *http.Request) {

	db := dbConn()
	seldb, err := db.Query("SELECT * FROM Plandetails ")
	cust := plan{}
	res := []plan{}
	if err != nil {
		panic(err.Error())
	}
	var id,plancost int
	var planduration,voicecalllimit,smslimit,datalimit string
	for seldb.Next() {
		
		err = seldb.Scan(&id,&planduration,&voicecalllimit,&datalimit,&smslimit,&plancost)
		if err != nil {
			panic(err.Error())
		}

	    cust.Planid=id
		cust.Plancost=plancost
		cust.Voicecalllimit=voicecalllimit
		cust.Datallimit=datalimit
		cust.Smslimit=smslimit
		cust.Planduration=planduration
		res = append(res, cust)

	}
	tmpl.ExecuteTemplate(w, "showplan", res)
	defer db.Close()
}
func EditPlan(w http.ResponseWriter, r *http.Request){
	
	db := dbConn()
	nId := r.URL.Query().Get("id")
	var id,plancost int
	var planduration,voicecalllimit,smslimit,datalimit string
	selDB, err := db.Query("SELECT * FROM Plandetails WHERE planid=?", nId)
	if err != nil {
		panic(err.Error())
	}
	cust:= plan{}
	for selDB.Next() {

		err = selDB.Scan(&id,&planduration,&voicecalllimit,&datalimit,&smslimit,&plancost)
		if err != nil {
			panic(err.Error())
		}
		cust.Planid=id
		cust.Plancost=plancost
		cust.Voicecalllimit=voicecalllimit
		cust.Datallimit=datalimit
		cust.Smslimit=smslimit
		cust.Planduration=planduration
		fmt.Println("cust",cust)
		
	}
	tmpl.ExecuteTemplate(w, "Editplan", cust)
	defer db.Close()
	//tmpl.ExecuteTemplate(w, "Edit", nil)
}
func Updateplan(w http.ResponseWriter, r *http.Request){
	db := dbConn()
	if r.Method == "POST" {
		duration:= r.FormValue("name")
		voicecalllimit := r.FormValue("altno")
		datalimit:=r.FormValue("number")
		smslimit:=r.FormValue("dob")
		Plancost:=r.FormValue("gender")
		id:=r.FormValue("id")
		fmt.Println("id",id)
		insForm, err := db.Prepare("UPDATE  Plandetails SET  planduration=?,voicecalllimit=?,datalimit=?,smslimit=?,plancost=? WHERE planid=?")
		if err != nil {
			panic(err.Error())
		}
		a,err:=insForm.Exec(duration,voicecalllimit,datalimit,smslimit,Plancost,id)
		fmt.Println(a)
		if err!=nil{
			panic(err.Error())
		}

        		
		
	}
	defer db.Close()

	http.Redirect(w, r, "/", 301)
}
func Expireallplan(w http.ResponseWriter, r *http.Request){
	fmt.Println("inside expiree")
	db := dbConn()
	db.Query("UPDATE  Customerdetails SET  planactive=? WHERE id>=0","EXPIRED")
	
	tmpl.ExecuteTemplate(w, "Expire", nil)
	
	defer db.Close()
}
func insertsubscrption(w http.ResponseWriter, r *http.Request){
	tmpl.ExecuteTemplate(w, "insertsubs", nil)
}
func searchonexpire(w http.ResponseWriter, r *http.Request){
	tmpl.ExecuteTemplate(w, "searchexpire", nil)
}

func searchexpire(w http.ResponseWriter, r *http.Request){
	db := dbConn()
	if r.Method == "POST" {
		duration:= r.FormValue("id")
		fmt.Println(duration)
		var id int
		insForm2, err := db.Query("Select  id from   Subscription  WHERE Plan_End_Date=?",duration)
		if err!=nil{
			panic(err.Error())
		}
		for insForm2.Next() {

			err = insForm2.Scan(&id)
			if err != nil {
				panic(err.Error())
			}		
	}
	seldb, err1 := db.Query("Select  * from   Customerdetails  WHERE planactive=? and id=?" ,"EXPIRED",id)
	if err1!=nil{
		panic(err.Error())
	}
	var id1,altno,number int
	var address,dob,planactive,gender,name ,pincode string
	cust := customer{}
	res := []customer{}
	for seldb.Next() {
		
		err = seldb.Scan(&id1,&name,&altno,&number,&dob,&gender,&address,&pincode,&planactive)
		if err != nil {
			panic(err.Error())
		}

	    cust.Ticket_id=id1
		cust.Name=name
		cust.Alternate_number=altno
		cust.Number=number
		cust.Pincode=pincode
		cust.Address=address
		cust.Date_of_birth=dob
		cust.Gender=gender
		cust.Planactive=planactive
		res = append(res, cust)

	}
	defer db.Close()
	if(len(res)>0){
	tmpl.ExecuteTemplate(w, "Show", res)
	}else{
		http.Redirect(w, r, "/", 301)
	}
	
}
}
func insertsub(w http.ResponseWriter, r *http.Request){
	db := dbConn()
	if r.Method == "POST" {
	//	id := r.FormValue("id")
		id:= r.FormValue("id")
		plan_id := r.FormValue("name")
		amount:=r.FormValue("amount")
		fmt.Println("id",id)
		currentTime := time.Now()
		var duration int
		
		insForm2, err2 := db.Query("Select  planduration from   Plandetails  WHERE planid=?",plan_id)
		
		if err2 != nil {
			panic(err2.Error())
		}
		for insForm2.Next() {
            err2 = insForm2.Scan(&duration)
			if err2!= nil {
				panic(err2.Error())
			}
        enddate:=currentTime.AddDate(0, 0,  duration)
        days := enddate.Sub(currentTime).Hours() / 24
		if(days<=0){
			db.Query("UPDATE  Customerdetails SET  planactive= ?  WHERE id=?","EXPIRED",id)
			
		}
		insForm, err := db.Prepare("INSERT INTO Subscription(id,planid,Total_Amount,Plan_Start_Date,Plan_End_Date) VALUES(?,?,?,?,?)")
		if err != nil {
			panic(err.Error())
		}
	  insForm.Exec(id,plan_id,amount,currentTime,enddate)
	  insForm1, err1 := db.Prepare("UPDATE  Customerdetails SET  planactive= ?  WHERE id=?")
	  
	  insForm1.Exec("Active",id)
	  
	  if err1 != nil {
		panic(err.Error())
	}
}

		//fmt.Println(id,name,altno,dob,gender,Address,Pincode,Planactive)
	}
	defer db.Close()
	http.Redirect(w, r, "/", 301)

}

func main() {

	log.Println("Server started on: http://localhost:30000")

	http.HandleFunc("/", Index)
	http.HandleFunc("/customerdetails", Enterdetails)
	// http.HandleFunc("/New", New)
	http.HandleFunc("/insert", insert)

	  http.HandleFunc("/show", Show)
	  http.HandleFunc("/search", Searchtemplate)
	  http.HandleFunc("/Searchdetails", Searchdetails)
	  http.HandleFunc("/plandetails", EnterPlandetails)
	  http.HandleFunc("/insertplan", insertplan)
	// http.HandleFunc("/new", New)
	http.HandleFunc("/edit", Edit)
   http.HandleFunc("/update", Update)
   http.HandleFunc("/Showplan", Showplan)
   http.HandleFunc("/editplan", EditPlan)
   http.HandleFunc("/updateplan", Updateplan)
   http.HandleFunc("/expireplan", Expireallplan)
  
   http.HandleFunc("/insertsubscrption", insertsubscrption)
   http.HandleFunc("/insertsub", insertsub)
   http.HandleFunc("/searchonexpire", searchonexpire)
   http.HandleFunc("/searchexpire", searchexpire)
	http.ListenAndServe(":30000", nil)

}